@extends('layouts.admin')

@section('container')

<div class="container">
  <h1 class="mb-5">{{ $title }}</h1>
  <h6>
    Halo, {{ Auth::user()->nama }}
  </h6>
  <span>Selamat datang</span>
</div>

@endsection
