@extends('layouts.main')

@section('container')

<div class="container mt-4 mb-5">
  <div class="card rounded-4 bg-primary-lrvl-grd">
    <div class="card-body p-5">

      <div class="w-100 text-light">
        <h1 class="text-center w-100 mb-5">{{ $title }}</h1>
      </div>

      <div class="row justify-content-center">
        <div class="col-7">

          @if (count($errors) > 0)
            <div class="alert alert-danger">
              <ul class="mb-0">
                @foreach ($errors->all() as $error)
                  <li>{{ $error }}</li>
                @endforeach
              </ul>
            </div>
          @endif

          <div class="card">
            <div class="card-body">
              <form action="/pendaftaran-siswa" method="POST">
                {{ csrf_field() }}

                <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="nisn">NISN</label>
                    <input type="text" class="form-control" name="nisn" id="nisn" value="{{ old('nisn') }}">
                  </div>
                  <div class="form-group col-md-6">
                    <label for="jenis-kelamin">Jenis Kelamin</label>
                    <select class="form-control" name="jenis-kelamin" id="jenis-kelamin">
                      <option value="">Pilih Jenis Kelamin</option>
                      <option value="laki-laki">Laki-laki</option>
                      <option value="perempuan">Perempuan</option>
                    </select>
                  </div>
                </div>
                <div class="form-group">
                  <label for="nama">Nama</label>
                  <input type="text" class="form-control" name="nama" id="nama" placeholder="Nama Lengkap" value="{{ old('nama') }}">
                </div>
                <div class="form-group">
                  <label for="asal-sekolah-select">Asal Sekolah</label>
                  <select class="form-control" name="asal-sekolah-select" id="asal-sekolah-select">
                    <option value="">Pilih Asal Sekolah</option>
                    <option>Lainnya</option>
                    <option>MTs AL ASMAAUL HUSNA</option>
                    <option>MTs Ar-Rasyidy</option>
                    <option>MTs AR-ROZZAAQ</option>
                    <option>MTs Assalaam</option>
                    <option>MTs Balighul Hikmah</option>
                    <option>MTs Darul Irsyad</option>
                    <option>MTs EL ALAMIA</option>
                    <option>MTs HIBRUL ULAMA</option>
                    <option>MTs MANBA'UL HUDA</option>
                    <option>MTs NUR AKMALIYAH</option>
                    <option>MTs NURANI</option>
                    <option>MTs NURUL FAJAR</option>
                    <option>MTs RIBATHUL MUJTABA</option>
                    <option>MTs RIYADHUL MUSTHOFA</option>
                    <option>MTs TAHFIDZ SMART MUROTTAL</option>
                    <option>MTs TANBIHUL GHOFILIN</option>
                    <option>MTs ULIN NUHA</option>
                    <option>MTs UTSMANIL HAKIM</option>
                    <option>MTs Yanfa''ul Ilmi</option>
                    <option>MTSN 1 BOGOR</option>
                    <option>MTSN 1 CIANJUR</option>
                    <option>MTSN 2 BOGOR</option>
                    <option>MTSN 2 CIANJUR</option>
                    <option>MTSN 3 BOGOR</option>
                    <option>MTSN 3 CIANJUR</option>
                    <option>MTSN 4 BOGOR</option>
                    <option>MTSN 4 CIANJUR</option>
                    <option>MTSN 5 CIANJUR</option>
                    <option>MTSN 6 CIANJUR</option>
                    <option>MTSN 7 CIANJUR</option>
                    <option>MTSN KOTA BOGOR</option>
                    <option>MTSN KOTA DEPOK</option>
                    <option>MTSN KOTA SUKABUMI</option>
                    <option>MTSS 2 KOTA SUKABUMI</option>
                    <option>MTSS ABDOELLAH BASTARI</option>
                    <option>MTSS ADAWIYATUL ASLAMIYAH</option>
                    <option>MTSS AINUR RAHMAH</option>
                    <option>MTSS AKHLAQIYYAH</option>
                    <option>MTSS AKMALIYAH</option>
                    <option>MTSS AL AMANAH</option>
                    <option>MTSS AL AMANAH</option>
                    <option>MTSS AL AMIN</option>
                    <option>MTSS AL ANHAR</option>
                    <option>MTSS AL ARAFAH</option>
                    <option>MTSS AL ARQOM</option>
                    <option>MTSS AL ASIYAH</option>
                    <option>MTSS AL ATIQIYAH</option>
                    <option>MTSS AL AWWABIN</option>
                    <option>MTSS AL AZIZIYYAH</option>
                    <option>MTSS AL BAKRIYAH</option>
                    <option>MTSS AL BAQIYATUSSHOLIHAT</option>
                    <option>MTSS AL BASHRIYYAH</option>
                    <option>MTSS AL FALAH</option>
                    <option>MTSS AL FALAH</option>
                    <option>MTSS AL FALAH</option>
                    <option>MTSS AL FALAH</option>
                    <option>MTSS AL FALAHIYAH</option>
                    <option>MTSS AL FARABI</option>
                    <option>MTSS AL FATA</option>
                    <option>MTSS AL FATAH</option>
                    <option>MTSS AL FATHONIYAH</option>
                    <option>MTSS AL FATMAHIYAH</option>
                    <option>MTSS AL FIKRI</option>
                    <option>MTSS AL FITRIYAH</option>
                    <option>MTSS AL FURQON</option>
                    <option>MTSS AL FURQON</option>
                    <option>MTSS AL FURQONIYAH</option>
                    <option>MTSS AL FURQONIYAH</option>
                    <option>MTSS AL GHIFFARI</option>
                    <option>MTSS AL GHIFFARI</option>
                    <option>MTSS AL HAMDANIYAH</option>
                    <option>MTSS AL HAMIDIYAH</option>
                    <option>MTSS AL HASANAH</option>
                    <option>MTSS AL HASANI</option>
                    <option>MTSS AL HIDAYAH</option>
                    <option>MTSS AL HIDAYAH</option>
                    <option>MTSS AL HIDAYAH</option>
                    <option>MTSS AL HIDAYAH</option>
                    <option>MTSS AL HIDAYAH</option>
                    <option>MTSS AL HIDAYAH</option>
                    <option>MTSS AL HIDAYAH</option>
                    <option>MTSS AL HIDAYAH</option>
                    <option>MTSS AL HIDAYAH 2</option>
                    <option>MTSS AL HIDAYAH CA</option>
                    <option>MTSS AL HIDAYAH CINANGKA</option>
                    <option>MTSS AL HIDAYAH RAWA DENOK</option>
                    <option>MTSS AL HIDAYAH SUKATANI</option>
                    <option>MTSS AL HIKMAH</option>
                    <option>MTSS AL HUDA</option>
                    <option>MTSS AL HUSAINIYAH</option>
                    <option>MTSS AL HUSNA</option>
                    <option>MTSS AL HUSNA</option>
                    <option>MTSS AL IDRUS</option>
                    <option>MTSS AL IHSAN</option>
                    <option>MTSS AL IHSANUL HUSNA</option>
                    <option>MTSS AL IHYA</option>
                    <option>MTSS AL IKHLAS</option>
                    <option>MTSS AL IKHLAS</option>
                    <option>MTSS AL IKHWAN</option>
                    <option>MTSS AL IKHWAN CIHEA</option>
                    <option>MTSS AL ILTIZAM</option>
                    <option>MTSS AL INAAYAH</option>
                    <option>MTSS AL INAYAH</option>
                    <option>MTSS AL IRSYADIYAH</option>
                    <option>MTSS AL ISLAMIYAH</option>
                    <option>MTSS AL ISLAMIYAH AMZ</option>
                    <option>MTSS AL ISTIQOMAH</option>
                    <option>MTSS AL ITQON</option>
                    <option>MTSS AL ITTIHAD</option>
                    <option>MTSS AL ITTIHAD</option>
                    <option>MTSS AL ITTIHAD MATHLAUL ANWAR</option>
                    <option>MTSS AL ITTIHADIYAH</option>
                    <option>MTSS AL JAMHURIYAH</option>
                    <option>MTSS AL JAYANI</option>
                    <option>MTSS AL JIHAD</option>
                    <option>MTSS AL KARIMIYAH</option>
                    <option>MTSS AL KAUTSAR</option>
                    <option>MTSS AL KHAIRIYAH</option>
                    <option>MTSS AL KHOERIYAH</option>
                    <option>MTSS AL KHOERIYAH</option>
                    <option>MTSS AL KINANAH</option>
                    <option>MTSS AL MA HADUL ISLAM</option>
                    <option>MTSS AL MADANI</option>
                    <option>MTSS AL MAKMUR</option>
                    <option>MTSS AL MANAR</option>
                    <option>MTSS AL MANSHURIYAH</option>
                    <option>MTSS AL MANSURI</option>
                    <option>MTSS AL MASYKUR</option>
                    <option>MTSS AL MASYKUR 02</option>
                    <option>MTSS AL MIZAN</option>
                    <option>MTSS AL MU AWWANAH</option>
                    <option>MTSS AL MUASYAROH</option>
                    <option>MTSS AL MUAWANAH</option>
                    <option>MTSS AL MUAWANAH</option>
                    <option>MTSS AL MUAWWANAH</option>
                    <option>MTSS AL MUCHTARI ISLAMIC BOARDING SCHOOL</option>
                    <option>MTSS AL MUHAJIRIN</option>
                    <option>MTSS AL MUHAJIRIN</option>
                    <option>MTSS AL MUJAHIDIN</option>
                    <option>MTSS AL MUKHLISHIN</option>
                    <option>MTSS AL MUKHLISIN</option>
                    <option>MTSS AL MUKHSIN</option>
                    <option>MTSS AL MUKHTAROMIYAH</option>
                    <option>MTSS AL MUROZZA</option>
                    <option>MTSS AL MUTTAQIN</option>
                    <option>MTSS AL-ABROR</option>
                    <option>MTSS AL-ACHDAN</option>
                    <option>MTSS AL-AFKAR</option>
                    <option>MTSS AL-AHSAN</option>
                    <option>MTSS AL-AKHYAR</option>
                    <option>MTSS AL-AMANAH</option>
                    <option>MTSS AL-ATHFAL</option>
                    <option>MTSS AL-BADAR</option>
                    <option>MTSS AL-BAQIATUSSHOLIHAT</option>
                    <option>MTSS AL-BARKAH</option>
                    <option>MTSS AL-BARKAH</option>
                    <option>MTSS AL-BARKAH</option>
                    <option>MTSS AL-BAROKAH</option>
                    <option>MTSS AL-BASIT</option>
                    <option>MTSS AL-BASYARIAH</option>
                    <option>MTSS AL-BAYAN</option>
                    <option>MTSS AL-FALAH</option>
                    <option>MTSS AL-FALAH</option>
                    <option>MTSS AL-FALAH</option>
                    <option>MTSS AL-FALAK</option>
                    <option>MTSS AL-FARISI</option>
                    <option>MTSS AL-FATAH</option>
                    <option>MTSS AL-FATH</option>
                    <option>MTSS AL-FITRIYAH</option>
                    <option>MTSS AL-GHOZALY</option>
                    <option>MTSS AL-HAMIDI</option>
                    <option>MTSS AL-HASANAH</option>
                    <option>MTSS AL-HIDAYAH</option>
                    <option>MTSS AL-HIDAYAH</option>
                    <option>MTSS AL-HIDAYAH</option>
                    <option>MTSS AL-HIDAYAH</option>
                    <option>MTSS AL-HIDAYAH ARCO</option>
                    <option>MTSS AL-HIKAM GOBANG</option>
                    <option>MTSS AL-HIKMAH</option>
                    <option>MTSS AL-HIKMAH</option>
                    <option>MTSS AL-HOLILIYAH</option>
                    <option>MTSS AL-HUDA</option>
                    <option>MTSS AL-HUDA</option>
                    <option>MTSS AL-HUDA CIDAUN</option>
                    <option>MTSS AL-HUDA RAWAHANJA</option>
                    <option>MTSS AL-IHSAN SARAMPAD</option>
                  </select>
                </div>
                <div class="form-group" id="asal-sekolah-input-container" style="display: none">
                  <label for="asal-sekolah-input">Nama Sekolah</label>
                  <input type="text" class="form-control" name="asal-sekolah-input" id="asal-sekolah-input" placeholder="Masukkan Asal Sekolah">
                </div>
                <div class="form-group">
                  <label for="email">Email</label>
                  <input type="email" class="form-control" name="email" id="email" value="{{ old('email') }}">
                </div>
                <div class="form-group">
                  <label for="no-hp">No. handphone</label>
                  <input type="text" class="form-control" name="no-hp" id="no-hp" value="{{ old('no-hp') }}">
                </div>
                <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="no-hp-ayah">No. HP Ayah</label>
                    <input type="text" class="form-control" name="no-hp-ayah" id="no-hp-ayah" value="{{ old('no-hp-ayah') }}">
                  </div>
                  <div class="form-group col-md-6">
                    <label for="no-hp-ibu">No. HP Ibu</label>
                    <input type="text" class="form-control" name="no-hp-ibu" id="no-hp-ibu" value="{{ old('no-hp-ibu') }}">
                  </div>
                </div>
                <div class="w-100 d-flex mt-3">
                  <button type="submit" class="btn btn-secondary-lrvl rounded-4 ml-auto">Registrasi</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

@endsection
