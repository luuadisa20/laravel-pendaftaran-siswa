@extends('layouts.main')

@section('container')

<div class="container">
  <h1>Halaman Tentang Kami</h1>
</div>

@endsection
