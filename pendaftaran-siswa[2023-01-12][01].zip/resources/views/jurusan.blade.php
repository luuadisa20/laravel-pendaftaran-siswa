@extends('layouts.main')

@section('container')

<div class="container">
  <h1>Halaman Jurusan</h1>
</div>

@endsection
