@extends('layouts.admin')

@section('container')

<div class="container">
  <h1 class="mb-5">{{ $title }}</h1>
  <span>Silahkan upload bukti bayar Anda di form berikut</span>

  <div class="card">
    <div class="card-body">
      <div class="form-row">
        <div class="form-group col-md-4">
          <label for="">Nama Bank</label>
          <input type="text" name="nama-bank" id="" class="form-control">
        </div>
        <div class="form-group col-md-4">
          <label for="">Nama Pemilik Rekening</label>
          <input type="text" name="nama-pemilik-rekening" id="" class="form-control">
        </div>
        <div class="form-group col-md-4">
          <label for="">Nominal</label>
          <input type="text" name="nominal" id="" class="form-control">
        </div>
      </div>
    </div>
  </div>
</div>

@endsection
