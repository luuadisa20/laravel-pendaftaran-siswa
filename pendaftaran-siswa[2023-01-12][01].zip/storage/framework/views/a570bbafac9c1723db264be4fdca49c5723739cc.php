

<?php $__env->startSection('container'); ?>

<div class="container mt-4 mb-5">
  <div class="card rounded-4 bg-primary-lrvl text-light">
    <div class="card-body p-5">

      <div class="w-100">
        <h1 class="text-center w-100 mb-5"><?php echo e($title); ?></h1>
      </div>
      
      <div class="row justify-content-center">
        <div class="col-md-4 col-md-offset-4">
          <h2 class="text-center">Tutorial Login Laravel</h2>
          <hr>
          <?php if(session('error')): ?>
            <div class="alert alert-danger">
              <b>Opps!</b> <?php echo e(session('error')); ?>

            </div>
          <?php endif; ?>

          <form action="<?php echo e(route('login')); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <div class="form-group">
                  <label>Email</label>
                  <input type="email" name="email" class="form-control" placeholder="Email" required="">
              </div>

              <div class="form-group">
                  <label>Password</label>
                  <input type="password" name="password" class="form-control" placeholder="Password" required="">
              </div>

              <button type="submit" class="btn btn-primary btn-block">Log In</button>

              
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\pendaftaran-siswa\resources\views/login.blade.php ENDPATH**/ ?>