

<?php $__env->startSection('container'); ?>

<div class="container">
  <h1>halaman beranda</h1>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\pendaftaran-siswa\resources\views/jurusan.blade.php ENDPATH**/ ?>