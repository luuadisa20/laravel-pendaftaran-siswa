<header class="flex-shrink-0">
  <nav class="navbar navbar-expand-lg navbar-dark main-nav-lrvl bg-primary-lrvl-grd">
    <div class="container">
      <a class="navbar-brand" href="/">
        <img src="/img/logo-wk.png" width="60" height="60" class="d-inline-block align-top" alt="" loading="lazy">
      </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item <?php echo e($title === 'Jurusan' ? 'active' : ''); ?>">
            <a class="nav-link" href="/dashboard">Dashboard</a>
          </li>
          <li class="nav-item <?php echo e($title === 'Tentang Kami' ? 'active' : ''); ?>">
            <a class="nav-link" href="/pembayaran">Pembayaran</a>
          </li>
          <li class="nav-item <?php echo e($title === 'Login' ? 'active' : ''); ?>">
            <a class="nav-link" href="/login">Logout</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
</header><?php /**PATH D:\Project\pendaftaran-siswa\resources\views/partials/nav-admin.blade.php ENDPATH**/ ?>