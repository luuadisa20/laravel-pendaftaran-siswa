

<?php $__env->startSection('container'); ?>

<div class="container">
  <h1><?php echo e($title); ?></h1>
  <h6>
    Halo, <?php echo e(Auth::user()->nama); ?>

  </h6>
  <span>Selamat datang</span>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\pendaftaran-siswa\resources\views/dashboard.blade.php ENDPATH**/ ?>