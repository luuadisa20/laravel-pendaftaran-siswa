

<?php $__env->startSection('container'); ?>

<div class="container">
  <h1 class="mb-5"><?php echo e($title); ?></h1>
  <span>Silahkan upload bukti bayar Anda di form berikut</span>

  <div class="card">
    <div class="card-body">
      <div class="form-row">
        <div class="form-group col-md-4">
          <label for=""></label>
          <input type="text" name="" id="" class="form-control">
        </div>
        <div class="form-group col-md-4">
          <label for=""></label>
          <input type="text" name="" id="" class="form-control">
        </div>
        <div class="form-group col-md-4">
          <label for=""></label>
          <input type="text" name="" id="" class="form-control">
        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\pendaftaran-siswa\resources\views/pembayaran.blade.php ENDPATH**/ ?>