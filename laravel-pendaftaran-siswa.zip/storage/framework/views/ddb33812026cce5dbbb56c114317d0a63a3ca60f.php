

<?php $__env->startSection('container'); ?>
  <div class="container pb-5">
    <h6>
      Halo, <?php echo e(Auth::user()->nama); ?>

    </h6>

    <div class="mb-4">
      <span>Selamat datang</span>
    </div>

    <?php if($siswa->status_registrasi == 'pending' && $siswa->bukti_pembayaran == ''): ?>
      <div class="alert alert-warning">Silahkan melakukan pembayaran untuk memproses pendaftaran.</div>
    <?php elseif($siswa->status_registrasi == 'pending' && $siswa->bukti_pembayaran != ''): ?>
      <div class="alert alert-warning">Pembayaran sedang diverifikasi, harap tunggu informasi selanjutnya.</div>
    <?php elseif($siswa->status_registrasi == 'accepted'): ?>
      <div class="alert alert-primary">Pembayaran diverifikasi, silahkan untuk melakukan proses selanjutnya.</div>
    <?php elseif($siswa->status_registrasi == 'denied'): ?>
      <div class="alert alert-danger">Verifikasi pembayaran gagal, silahkan lakukan proses ulang pendaftaran.</div>
    <?php endif; ?>

    <?php if(session()->has('message')): ?>
      <p class="alert <?php echo e(session('alert-class')); ?>"><?php echo e(session('message')); ?></p>
    <?php endif; ?>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\laravel-pendaftaran-siswa\resources\views/dashboard-student.blade.php ENDPATH**/ ?>