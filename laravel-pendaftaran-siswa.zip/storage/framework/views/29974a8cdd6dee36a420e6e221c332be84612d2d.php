

<?php $__env->startSection('container'); ?>
  <div class="container">
    <h6>
      Halo, <?php echo e(Auth::user()->nama); ?>

    </h6>

    <div class="mb-4">
      <span>Selamat datang</span>
    </div>

    <div class="alert alert-warning">Silahkan mengecek data pendaftaran beserta bukti pembayaran para calon siswa!</div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\laravel-pendaftaran-siswa\resources\views/dashboard.blade.php ENDPATH**/ ?>