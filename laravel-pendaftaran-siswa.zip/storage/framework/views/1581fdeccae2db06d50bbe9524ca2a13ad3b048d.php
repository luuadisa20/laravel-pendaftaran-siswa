

<?php $__env->startSection('container'); ?>
  <div class="container">
    <h6>
      Halo, <?php echo e(Auth::user()->nama); ?>

    </h6>

    <div class="mb-4">
      <span>Selamat datang</span>
    </div>

    <div class="d-flex">
      <div class="card" style="width: 100%;">
        <div class="card-body text-center">
          <?php if($siswa->bukti_pembayaran !== null): ?>
            <img src="<?php echo e(asset('pembayaran/' . $siswa->bukti_pembayaran)); ?>" class="img-thumbnail mb-3">
          <?php endif; ?>
          <p class="card-text">
            Nama Bank : <?php echo e($siswa->nama_bank); ?><br>
            Nama Pemilik Rekening : <?php echo e($siswa->nama_pemilik_rekening); ?><br>
            Nominal : <?php echo e($siswa->nominal); ?>

          </p>
          <a href="/page-pembayaran">Kembali</a>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\laravel-pendaftaran-siswa\resources\views/detail.blade.php ENDPATH**/ ?>