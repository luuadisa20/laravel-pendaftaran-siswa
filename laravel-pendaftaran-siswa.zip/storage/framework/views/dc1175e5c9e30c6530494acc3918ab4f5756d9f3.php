

<?php $__env->startSection('container'); ?>
  <div class="container pb-5">
    <h6>
      Halo, <?php echo e(Auth::user()->nama); ?>

    </h6>

    <div class="mb-4">
      <span>Selamat datang</span>
    </div>

    <div class="d-flex">
      <div class="card" style="width: 100%;">
        <div class="card-body">
          <div class="mb-3">
            <li>NISN : <?php echo e($siswa->nisn); ?></li>
            <li>Nama Siswa : <?php echo e($siswa->nama); ?></li>
            <li>Jenis Kelamin : <?php echo e($siswa->jenis_kelamin); ?></li>
            <li>Asal Sekolah : <?php echo e($siswa->asal_sekolah); ?></li>
            <li>Email : <?php echo e($siswa->email); ?></li>
            <li>No. HP : <?php echo e($siswa->no_hp); ?></li>
            <li>No. HP Ayah : <?php echo e($siswa->no_hp_ayah); ?></li>
            <li>No. HP Ibu : <?php echo e($siswa->no_hp_ibu); ?></li>
          </div>
          <a href="/page-pembayaran">Kembali</a>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\laravel-pendaftaran-siswa\resources\views/detail-pendaftaran.blade.php ENDPATH**/ ?>