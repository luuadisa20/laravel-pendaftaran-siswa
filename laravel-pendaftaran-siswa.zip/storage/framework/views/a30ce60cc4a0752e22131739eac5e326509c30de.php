<?php $__env->startSection('content'); ?>
  <div class="container mt-4 mb-5">
    <div class="row justify-content-center">
      <div class="col-md-7">

        <div class="card rounded-4 bg-primary-lrvl-grd text-light">
          <div class="card-body p-5">

            <div class="w-100">
              <h1 class="text-center w-100 mb-5">LOGIN</h1>
            </div>

            <div class="row justify-content-center">
              <div class="col-md-8">
                <form action="<?php echo e(route('login')); ?>" method="POST">
                  <?php echo csrf_field(); ?>

                  <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email"
                      class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> rounded-4" placeholder="Email" required
                      value="<?php echo e(old('email')); ?>" autocomplete="email" autofocus>

                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                      </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>

                  <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password"
                      class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> rounded-4" placeholder="Password"
                      required="">

                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                      </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>

                  <div class="form-group row">
                    <div class="col-md-6">
                      <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="remember" id="remember"
                          <?php echo e(old('remember') ? 'checked' : ''); ?>>

                        <label class="form-check-label" for="remember">
                          <?php echo e(__('Remember Me')); ?>

                        </label>
                      </div>
                    </div>
                  </div>

                  <button type="submit" class="btn btn-block btn-secondary-lrvl rounded-4">
                    <?php echo e(__('Login')); ?>

                  </button>

                  <hr>

                  <?php if(Route::has('password.request')): ?>
                    <p class="text-center">
                      <a class="btn btn-link text-center"
                        href="<?php echo e(route('password.request')); ?>"><?php echo e(__('Forgot Your Password?')); ?></a>
                    </p>
                  <?php endif; ?>

                  <p class="text-center">Belum punya akun? <a href="/pendaftaran-siswa">Daftar</a> sekarang!</p>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\laravel-pendaftaran-siswa\resources\views/auth/login.blade.php ENDPATH**/ ?>