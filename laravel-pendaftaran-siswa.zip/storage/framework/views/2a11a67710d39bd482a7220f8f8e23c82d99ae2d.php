

<?php $__env->startSection('container'); ?>
  <div class="container pb-5">
    <div class="d-flex flex-column">
      <table class="table table-striped table-bordered table-hover">
        <thead>
          <tr>
            <th>No. Registrasi</th>
            <th>Nama</th>
            <th>Bukti Pembayaran</th>
            <th>Detail Pendaftaran</th>
            <th>Status Pembayaran</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $pendaftaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($siswa->id); ?></td>
              <td><?php echo e($siswa->nama); ?></td>
              <td>
                <?php if($siswa->bukti_pembayaran === null): ?>
                  <strong class="text-primary-lrvl">Lihat</strong>
                <?php else: ?>
                  <a href="/detail-pembayaran/<?php echo e($siswa->id); ?>">
                    <strong class="text-primary-lrvl">Lihat</strong>
                  </a>
                <?php endif; ?>

              </td>
              <td>
                <a href="/detail-pendaftaran/<?php echo e($siswa->id); ?>">
                  <strong class="text-primary-lrvl">Detail</strong>
                </a>
              </td>
              <td>
                <?php if($siswa->status_registrasi === 'accepted'): ?>
                  Pembayaran Valid
                <?php elseif($siswa->status_registrasi === 'denied'): ?>
                  Ditolak
                <?php elseif($siswa->status_registrasi === 'pending'): ?>
                  <?php if($siswa->bukti_pembayaran === null): ?>
                    Belum Bayar
                  <?php else: ?>
                    <button class="btn btn-sm btn-success btn-verifikasi" data-id="<?php echo e($siswa->id); ?>">Verifikasi</button>

                    <button class="btn btn-sm btn-danger btn-tolak" data-id="<?php echo e($siswa->id); ?>">Tolak</button>
                  <?php endif; ?>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>

      <div class="d-flex justify-content-end">
        <?php echo e($pendaftaran->links()); ?>

      </div>
    </div>
  </div>

  <form action method="POST" id="form-pendaftaran">
    <?php echo e(csrf_field()); ?>


    <input type="hidden" name="id" id="id-pendaftaran">
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\laravel-pendaftaran-siswa\resources\views/pembayaran.blade.php ENDPATH**/ ?>